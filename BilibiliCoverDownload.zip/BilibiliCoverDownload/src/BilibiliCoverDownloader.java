import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BilibiliCoverDownloader {
    public static void main(String[] args) {
        String baseUrl = "https://api.bilibili.com/x/space/wbi/arc/search?mid=14653055&ps=30&tid=0&pn=2&keyword=&order=pubdate&order_avoided=true&w_rid=0228a328be51ccabee2910f72752fcc8&wts=1671593801";
        for (int i = 21; i < 37; i++) {
            downloadPage(baseUrl,i);
        }
    }
    
    public static void downloadPage(String baseUrl,int pageNumber){
        try {
            baseUrl = baseUrl.replaceFirst("pn=.","pn="+pageNumber);
            URL url = new URL(baseUrl);
            URLConnection URLconnection = url.openConnection();
            URLconnection.addRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.3; WOW64; Trident/7.0; rv:11.0) like Gecko");
            //设置请求超时为5s
            URLconnection.setConnectTimeout(5*1000);
            HttpURLConnection httpConnection = (HttpURLConnection) URLconnection;
            int responseCode = httpConnection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                System.err.println("成功");
                InputStream in = httpConnection.getInputStream();
                InputStreamReader isr = new InputStreamReader(in);
                BufferedReader bufr = new BufferedReader(isr);
                String str;
                String imgURLPattern = "http://[a-zA-Z0-9\\./]+jpg";
                List<String> pageCoverImgList = null;
                while ((str = bufr.readLine()) != null) {
                    System.out.println(str);
                    pageCoverImgList = findAll(str,imgURLPattern);
                }
                Random random = new Random();
                for (String imgUrl : pageCoverImgList) {
                    Thread.sleep(random.nextInt(1000));
                    ImgDownloader.download(imgUrl);
                }
                bufr.close();
            } else {
                System.err.println("失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static List<String> findAll(String line,String pattern){
        List<String> resultList = new ArrayList<>();
        // 按指定模式在字符串查找
        //String line = "This order was placed for QT3000! OK?";
        //String pattern = "(\\D*)(\\d+)(.*)";

        // 创建 Pattern 对象
        Pattern r = Pattern.compile(pattern);

        // 现在创建 matcher 对象
        Matcher m = r.matcher(line);
        //System.out.println(m.group());
        //resultList.add(m.group());
        while (m.find( )) {
            resultList.add(m.group());
            System.out.println("Found value: " + m.group() );
        }
        return resultList;
    }
}
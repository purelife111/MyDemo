import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;

public class URLTest2 {
    public static void main(String args[]) throws Exception {
        try {
            URL url = new URL("https://api.bilibili.com/x/space/wbi/arc/search?mid=14653055&ps=30&tid=0&pn=2&keyword=&order=pubdate&order_avoided=true&w_rid=0228a328be51ccabee2910f72752fcc8&wts=1671593801");
            InputStream in =url.openStream();
            InputStreamReader isr = new InputStreamReader(in);
            BufferedReader bufr = new BufferedReader(isr);
            String str;
            while ((str = bufr.readLine()) != null) {
                System.out.println(str);
            }
            bufr.close();
            isr.close();
            in.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
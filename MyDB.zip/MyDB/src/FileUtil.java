import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class FileUtil {
    public static List<List<String>> readTable(String tableName){
        String filePath = "resource/DB1/"+tableName+".csv";
        List<List<String>> lists = readCsvByBufferedReader(filePath);
        return lists;
    }

    public void overwriteTable(List<List<String>> lists){

    }

    public void createTable(List<List<String>> lists){

    }

    /**
     * BufferedReader 读取
     * @param filePath
     * @return
     */
    public static ArrayList<List<String>> readCsvByBufferedReader(String filePath) {
        File csv = new File(filePath);
        csv.setReadable(true);
        csv.setWritable(true);
        InputStreamReader isr = null;
        BufferedReader br = null;
        try {
            isr = new InputStreamReader(new FileInputStream(csv), "UTF-8");
            br = new BufferedReader(isr);
        } catch (Exception e) {
            e.printStackTrace();
        }
        String line = "";
        ArrayList<List<String>> records = new ArrayList<>();
        try {
            while ((line = br.readLine()) != null) {
                System.out.println(line);
                List<String> row = Arrays.asList(line.split(","));
                records.add(row);
            }
            System.out.println("csv表格读取行数：" + records.size());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return records;
    }

    public static void main(String[] args) {
        //
        ArrayList<List<String>> list = readCsvByBufferedReader("resource/user.csv");
        System.out.println(list.get(1).get(2));
    }
}

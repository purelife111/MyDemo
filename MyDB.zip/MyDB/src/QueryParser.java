import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class QueryParser {
    public QueryType getQueryType(String query){
        String firstWord = query.substring(0,query.indexOf(" ")).toUpperCase();
        switch (firstWord){
            case "SELECT":
                return QueryType.SELECT;
            case "DELETE":
                return QueryType.DELETE;
            case "INSERT":
                return QueryType.INSERT;
            case "UPDATE":
                return QueryType.UPDATE;
        }
        return null;
    }

    public List<String> getSelectColumns(String query){
        List<String> selectColumns = new ArrayList<>();
        String selectString = query.substring(query.indexOf("t")+1,query.indexOf("from"));
        selectString = selectString.trim();
        if ("*".equals(selectString)){
            File file = new File("resource/DB1/"+getTableName(query)+".csv");
            BufferedReader in ;
            try {
                in = new BufferedReader(new FileReader(file));
                String tableHeader = in.readLine();
                selectColumns = Arrays.asList(tableHeader.split(","));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }else{
            selectColumns = Arrays.asList(selectString.split(","));
        }

        return selectColumns;
    }

    public String getTableName(String query){
        String tableName = null;
        String s1 = query.substring(query.indexOf("from")+5);
        if (s1.contains(" ")){
            tableName = s1.substring(0,s1.indexOf(" "));
        }else {
            tableName = s1;
        }
        tableName = tableName.substring(tableName.indexOf(".")+1);
        return tableName;
    }

    public String getDBName(String query){
        String s1 = query.substring(query.indexOf("from")+5);
        String tableName = s1.substring(0,s1.indexOf(" "));
        String DBName = tableName.substring(0,tableName.indexOf("."));
        return DBName;
    }

    public List<String> getCriterias(String query){
        List<String> criteriaStrs = null;
        String criterString = query.substring(query.indexOf("where")+6).replace(" ","");
        criteriaStrs = Arrays.asList(criterString.split("and"));
        return criteriaStrs;
    }

    public List<Criteria> genCriterias(String query){
        List<Criteria> criteriaList = new ArrayList<>();
        List<String> criteriaStrs = getCriterias(query);
        for (String criteriaStr : criteriaStrs) {
            if (criteriaStr.contains(">=")){
                String strs[] = criteriaStr.split(">=");
                Criteria criteria = new Criteria(strs[0],-1,CriteriaType.GREATER_OR_EQUAL,strs[1]);
                criteriaList.add(criteria);
            } else if (criteriaStr.contains("<=")){
                String strs[] = criteriaStr.split("<=");
                Criteria criteria = new Criteria(strs[0],-1,CriteriaType.LESS_OR_EQUAL,strs[1]);
                criteriaList.add(criteria);
            }else if (criteriaStr.contains(">")){
                String strs[] = criteriaStr.split(">");
                Criteria criteria = new Criteria(strs[0],-1,CriteriaType.GREATER_THAN,strs[1]);
                criteriaList.add(criteria);
            } else if (criteriaStr.contains("!=")) {
                String strs[] = criteriaStr.split("!=");
                Criteria criteria = new Criteria(strs[0],-1,CriteriaType.NOT_EQUAL,strs[1]);
                criteriaList.add(criteria);
            } else if (criteriaStr.contains("=")) {
                String strs[] = criteriaStr.split("=");
                Criteria criteria = new Criteria(strs[0],-1,CriteriaType.EQUAL,strs[1]);
                criteriaList.add(criteria);
            } else if (criteriaStr.contains("<")) {
                String strs[] = criteriaStr.split("<");
                Criteria criteria = new Criteria(strs[0],-1,CriteriaType.LESS_THAN,strs[1]);
                criteriaList.add(criteria);
            } else if (criteriaStr.contains("in(")) {
                String column = criteriaStr.substring(0,criteriaStr.indexOf("in("));
                String args = criteriaStr.substring(criteriaStr.indexOf("in(")+3,criteriaStr.lastIndexOf(")"));
                Criteria criteria = new Criteria(column,-1,CriteriaType.LESS_THAN,args);
                criteriaList.add(criteria);
            }
        }
        return criteriaList;
    }

    public static void main(String[] args) {
        QueryParser queryParser = new QueryParser();
        String query1 = "select * from db1.user";
        System.out.println(queryParser.getQueryType(query1));
        String query4 = "select id,phone,age from db1.user where id>2 and age<30";
//        System.out.println(queryParser.getSelectColumns(query4));
//        System.out.println(queryParser.getSelectColumns(query1));
//        System.out.println(queryParser.getTableName(query4));
//        System.out.println(queryParser.getDBName(query4));
//        System.out.println(queryParser.getCriterias(query4));
        System.out.println(queryParser.genCriterias(query4));
    }
}

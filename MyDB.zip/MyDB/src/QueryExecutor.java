import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class QueryExecutor {
    public ResultSet executeSelect(String query){
        QueryParser queryParser = new QueryParser();
        String tableName = queryParser.getTableName(query);
        List<Criteria> criteriaList = queryParser.genCriterias(query);
        List<List<String>> table = FileUtil.readTable(tableName);
        List<String> selectColumns = queryParser.getSelectColumns(query);
        List<String> tableHeader = table.get(0);
        List<Integer> selectColumnsIndex = new ArrayList<>(selectColumns.size());
        Map<String,Integer> map = new HashMap<>();
        for (int i = 0; i < tableHeader.size(); i++) {
            map.put(tableHeader.get(i),i);
        }
        for (String selectColumn : selectColumns) {
            selectColumnsIndex.add(map.get(selectColumn));
        }
        List<List<String>> result = new ArrayList<>();
        for (Criteria criteria : criteriaList) {
            criteria.setColumnIndex(map.get(criteria.getColumn()));
        }

        for (int i = 0; i < table.size(); i++) {
            List<String> row = table.get(i);
            boolean isMatched = true;
            for (Criteria criteria : criteriaList) {
                switch (criteria.getCriteriaType()){
                    case GREATER_THAN:
                        if(row.get(criteria.getColumnIndex()).compareTo(criteria.getCriteriaArg())<=0){
                            isMatched = false;
                        }
                        break;
                    case LESS_THAN:
                        if(row.get(criteria.getColumnIndex()).compareTo(criteria.getCriteriaArg())>=0){
                            isMatched = false;
                        }
                        break;
                    case EQUAL:
                        if(row.get(criteria.getColumnIndex()).compareTo(criteria.getCriteriaArg())!=0){
                            isMatched = false;
                        }
                        break;
                    case NOT_EQUAL:
                        if(row.get(criteria.getColumnIndex()).compareTo(criteria.getCriteriaArg())==0){
                            isMatched = false;
                        }
                        break;
                    case IN:
                        if(!criteria.getCriteriaArg().contains(row.get(criteria.getColumnIndex()))){
                            isMatched = false;
                        }
                        break;
                    case GREATER_OR_EQUAL:
                        if(row.get(criteria.getColumnIndex()).compareTo(criteria.getCriteriaArg())<0){
                            isMatched = false;
                        }
                        break;
                    case LESS_OR_EQUAL:
                        if(row.get(criteria.getColumnIndex()).compareTo(criteria.getCriteriaArg())>0){
                            isMatched = false;
                        }
                        break;
                }
            }
            if (!isMatched){
                continue;
            }
            List<String> resultRow = new ArrayList<>();
            for (Integer columnsIndex : selectColumnsIndex) {
                resultRow.add(row.get(columnsIndex));
            }
            result.add(resultRow);
        }
        ResultSet resultSet = new ResultSet(result);
        return resultSet;
    }

    public static void main(String[] args) {
        QueryExecutor queryExecutor = new QueryExecutor();
        String query4 = "select * from db1.user where age>22 and name in (Jeff,Julia)";
        //System.out.println(queryExecutor.executeSelect(query4));
        System.out.println(queryExecutor.executeSelect(query4));
//        System.out.println("1".compareTo("0"));
//        System.out.println("1".compareTo("1"));
//        System.out.println("3".compareTo("9"));
//        System.out.println("qwer".compareTo("qwer"));
//        System.out.println("qwe".compareTo("qwf"));
//        System.out.println("qaz".compareTo("qaza"));
//        System.out.println("qazaa".compareTo("qaza"));
    }
}

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        String query1 = "select * from db1.user";
        String query2 = "select id,name,age from db1.user";
        String query3 = "select id,phone,age from db1.user where id>2";
        String query4 = "select id,phone,age from db1.user where id>2 and age<30";

    }
}
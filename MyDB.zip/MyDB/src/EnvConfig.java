public class EnvConfig {
    private String DBName;

    public EnvConfig(String DBName) {
        this.DBName = DBName;
    }

    public String getDBName() {
        return DBName;
    }

    public void setDBName(String DBName) {
        this.DBName = DBName;
    }
}

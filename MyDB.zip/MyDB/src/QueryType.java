public enum QueryType {
    SELECT,INSERT,DELETE,UPDATE
}

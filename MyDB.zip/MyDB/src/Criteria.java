public class Criteria {
    private String column;

    private int columnIndex;
    private CriteriaType criteriaType;
    private String criteriaArg;

    public Criteria() {
    }

    public Criteria(String column, int columnIndex, CriteriaType criteriaType, String criteriaArg) {
        this.column = column;
        this.columnIndex = columnIndex;
        this.criteriaType = criteriaType;
        this.criteriaArg = criteriaArg;
    }

    public String getColumn() {
        return column;
    }

    public void setColumn(String column) {
        this.column = column;
    }

    public int getColumnIndex() {
        return columnIndex;
    }

    public void setColumnIndex(int columnIndex) {
        this.columnIndex = columnIndex;
    }

    public CriteriaType getCriteriaType() {
        return criteriaType;
    }

    public void setCriteriaType(CriteriaType criteriaType) {
        this.criteriaType = criteriaType;
    }

    public String getCriteriaArg() {
        return criteriaArg;
    }

    public void setCriteriaArg(String criteriaArg) {
        this.criteriaArg = criteriaArg;
    }
}

import java.util.ArrayList;
import java.util.List;

public class ResultSet {
    private List<List<String>> result;

    public ResultSet() {
        this.result = new ArrayList<>();
    }

    public ResultSet(List<List<String>> result) {
        this.result = result;
    }

    public List<List<String>> getResult() {
        return result;
    }

    public void setResult(List<List<String>> result) {
        this.result = result;
    }

    public void printResult(){
        for (List<String> row : result) {
//            for (String column : row) {
//                System.out.print(column+",");
//            }
            for (int i = 0; i < row.size()-1; i++) {
                System.out.print(row.get(i)+",");
            }
            //print last column
            if (row.size()>0){
                System.out.print(row.get(row.size()-1));
            }
            System.out.println();
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (List<String> row : result) {
            for (int i = 0; i < row.size()-1; i++) {
                sb.append(row.get(i)+",");
            }
            //print last column
            if (row.size()>0){
                sb.append(row.get(row.size()-1));
            }
            sb.append("\n");
        }
        return sb.toString();
    }

    public static void main(String[] args) {
        ResultSet rs = new ResultSet();
        List<List<String>> lists = new ArrayList<>();
        String row11[] = {"1","tom"};
        List<String> row1 = new ArrayList<>();
        row1.add("1");row1.add("tom");
        List<String> row2 = new ArrayList<>();
        row2.add("2");row2.add("jack");
        lists.add(row1);lists.add(row2);
        rs.setResult(lists);
        rs.printResult();
        System.out.println(rs);
    }
}
